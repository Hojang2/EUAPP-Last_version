package de.bbs_donnersbergkreis.www.schoolapp.Italy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import de.bbs_donnersbergkreis.www.schoolapp.Germany.Germany_Discussion_blog;
import de.bbs_donnersbergkreis.www.schoolapp.Germany.Germany_Gallery;
import de.bbs_donnersbergkreis.www.schoolapp.Germany.Germany_Mini_Games;
import de.bbs_donnersbergkreis.www.schoolapp.Germany.Germany_School_Info;
import de.bbs_donnersbergkreis.www.schoolapp.Germany.Germany_Teachers;
import de.bbs_donnersbergkreis.www.schoolapp.Germany.Germany_location;
import de.bbs_donnersbergkreis.www.schoolapp.Germany.Germany_menu;
import de.bbs_donnersbergkreis.www.schoolapp.R;

public class IT_pictures extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_it_pictures);

    }
}
