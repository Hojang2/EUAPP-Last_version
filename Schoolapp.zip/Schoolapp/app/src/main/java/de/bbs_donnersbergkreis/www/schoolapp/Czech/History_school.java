package de.bbs_donnersbergkreis.www.schoolapp.Czech;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

import de.bbs_donnersbergkreis.www.schoolapp.R;

public class History_school extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView (R.layout.activity_cze_history);
        EditText editText = (EditText) findViewById(R.id.search);
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    //sendMessage();
                    handled = true;
                }
                return handled;
            }
        });
        //Provide Auto-complet

    }
    /*
    public void run() {
        Boolean end = false;
        ServerSocket ss = serverSocket;

    try {
        ss = new ServerSocket(54546);
    } catch (IOException e1) {
        //TODO Auto-generated catch block
        e1.printStackTrace();
    }
        while(!end){
            //Server is waiting for client here, if needed
            try {
                Log.i("before accept", "yes");
                Socket s = ss.accept();

                BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
                //PrintWriter output = new PrintWriter(s.getOutputStream(),true); //Autoflush
                String st = input.readLine();
                //Log.d("Tcp Example", "From client: "+st);
                //output.println("Good bye and thanks for all the fish :)");
            }catch (IOException e) {
                e.printStackTrace();
            }
        }
    }*/

}
